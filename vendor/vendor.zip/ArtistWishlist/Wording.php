<?php 
namespace ArtistWishlist;

/**
* 
*/
class Wording
{
	public static $POLLING_SUCCESS = "Thanks for your vote";
	public static $POLLING_DOUBLE = "You've already vote this artist";
	public static $POLLING_ERROR = "Sorry, an error has occurred please try again later";
}

?>